#import <Flutter/Flutter.h>

@interface RazorpayFlutterCustomuiPlugin : NSObject<FlutterPlugin>
@end
