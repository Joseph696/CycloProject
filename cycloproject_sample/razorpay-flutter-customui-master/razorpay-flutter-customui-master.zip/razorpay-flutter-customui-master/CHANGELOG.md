## 1.0.0

- TODO: Describe initial release.

## 1.1.0

- Android Callback issue fixed.
- Added validate VPA.

## 1.1.1

- Bug fixes

## 1.1.2

- Bug fixes on android

## 1.2.0

- Validate VPA fixes

## 1.2.1

- iOS bug fix for UPI supported Apps response.

## 1.2.2

- iOS bug fix on Payment cancel callback by the user
- Build issue fix on flutter run

## 1.2.3

- Dashboard Monitoring and Alerting
- Android bug fixes

## 1.3.0

- Added native dependency via cocoapods
- Minor bug fixes

## 1.3.1

- Exposed getBankLogoUrl

## 1.3.2

- getBankLogoUrl Bug Fix

## 1.3.3

- Removed JCenter from build.gradle for android due to Deprecation

